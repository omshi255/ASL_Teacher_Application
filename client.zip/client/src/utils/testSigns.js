export const TEST_SIGNS = [
  "Hello",
  "Yes",
  "No",
  "Stop",
  "Help",
  "Please",
  "Sorry",
  "Thank You",
  "Good",
  "Understand",
];
