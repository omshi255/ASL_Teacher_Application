export const formatDate = (iso) => new Date(iso).toLocaleString("en-IN");
